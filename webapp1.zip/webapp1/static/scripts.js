    // Configure typeahead
    $("#phone").typeahead({
        highlight: false,
        minLength: 1
    },
    {
       // Also, handlebars is nice.  It's very easy to use.
       display: function(suggestion) {return null;},
        limit: 12,
        source: search,
        templates: {
            suggestion: Handlebars.compile(
                "<div>" +
                "{{area_code}}, {{HSPH_phone}}"+
                "</div>"
            )
        }
    });