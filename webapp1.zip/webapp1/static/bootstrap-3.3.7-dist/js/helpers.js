HTTP 200 OK
Content-Type: application/json

{
    "name": "Drakeposting",
    "description": "http://knowyourmeme.com/memes/drakeposting",
    "aliases": [
        "always-on-beat",
        "drake",
        "drakeposting"
    ],
    "styles": [
        "beat",
        "no",
        "padding",
        "yes"
    ],
    "example": "https://memegen.link/api/templates/drake/your_text/goes_here"
}